package main

import "api/routes"

func main() {
	routes.GinSetup()
}
